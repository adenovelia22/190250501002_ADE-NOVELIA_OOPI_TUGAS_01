
package Limas;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CodingLimas {
    public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        Limas.ProsesLimas Limas = new Limas.ProsesLimas ();
        try 
        {
            System.out.println("Masukkan Nilai Luas Limas");
            String l = dataIn.readLine();
            Limas.setLuas(Integer.parseInt (l));
            
            System.out.println("Masukkan Nilai Tinggi Limas");
            String b = dataIn.readLine ();
            Limas.setTinggi(Integer.parseInt (b));
            
            System.out.println("Luas luas limas="+Limas.getLuas());
            System.out.println("Tinggi limas="+Limas.getTinggi ());
            System.out.println("Volume limas="+Limas.hitungVolume ());
        }
       
        catch (IOException e)
        {
            System.out.println("Data yang di input salah");
        }
     }
    
    
}
