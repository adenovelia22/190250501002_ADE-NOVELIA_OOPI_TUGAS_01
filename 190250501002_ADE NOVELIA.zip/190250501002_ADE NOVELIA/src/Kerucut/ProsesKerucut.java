
package Kerucut;


public class ProsesKerucut {
 private int Jari;
    private int Tinggi;
    
     public void setJari (int Jari)
    {
        this.Jari=Jari;
    }
    public void setTinggi (int tinggi)
    {
        this.Tinggi=tinggi;
    }
    public int getJari ()
    {
        return Jari;
    }
    public int getTinggi ()
    {
        return Tinggi;
    }
    public double hitungVolume()
    {
        double Volume;
        Volume=Jari * Jari * Tinggi * 3.14 * 1/3;
        return Volume;
    }    
      
}
