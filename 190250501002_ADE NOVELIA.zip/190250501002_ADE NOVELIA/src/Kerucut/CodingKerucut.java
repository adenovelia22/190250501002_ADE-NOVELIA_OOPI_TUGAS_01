
package Kerucut;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CodingKerucut {
    public static void main(String[] args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        Kerucut.ProsesKerucut kerucut = new Kerucut.ProsesKerucut ();
        try
        {
            System.out.println("inputkan Jarijari");
            String r = dataIn.readLine();
            kerucut.setJari(Integer.parseInt (r));
            
            System.out.println("inputkan Tinggi");
            String t = dataIn.readLine ();
            kerucut.setTinggi(Integer.parseInt (t));
            
            System.out.println("Jarijari kerucut="+kerucut.getJari());
            System.out.println("Tinggi kerucut="+kerucut.getTinggi ());
            System.out.println("Volume kerucut="+kerucut.hitungVolume ());
             
        }
        catch (IOException e)
        {
            System.out.println("Data yang di input salah");
        }
     }
    }
