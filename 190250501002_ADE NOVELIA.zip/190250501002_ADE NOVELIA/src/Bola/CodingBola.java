
package Bola;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CodingBola {
    public static void main(String[]args)throws IOException {
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        Bola.ProsesBola Bola = new Bola.ProsesBola ();
        try 
        {
            System.out.println("Masukkan Jarijari");
            String s = dataIn.readLine();
            Bola.setJari(Integer.parseInt (s));
          
            System.out.println("Jarijari Bola=");
            int jari = Bola.getJari();
            System.out.println("Volume Bola="+Bola.hitungVolume ());
        }
            catch (IOException e)        
        {
          System.out.println("Data yang di input salah");
        }
        
    }
    
}
