
package Bola;
public class ProsesBola {
     private int Jari;
    
    public void setJari(int Jarijari )
    {
        this.Jari = Jarijari;
    }
    
    public int getJari()
    {
        return Jari;
    }
  
        public double hitungVolume()
        {
            double Volume;
            Volume=4/3 * 3.14 * (Jari * Jari * Jari);
            return Volume;
        }  
}

  
