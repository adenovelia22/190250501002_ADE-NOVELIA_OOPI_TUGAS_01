
package Tabung;
public class ProsesTabung {
     private int Jari;
    private int Tinggi;
    
    public void setJarijari (int Jarijari )
    {
        this.Jari = Jarijari;
    }
    public void setTinggi (int tinggi)
    {
        this.Tinggi=tinggi;
    }
    public int getJarijari()
    {
        return Jari;
    }
    public int getTinggi()
    {
        return Tinggi;       
    }
        public double hitungVolume()
        {
            double Volume;
            Volume=3.14 * Jari * Jari * Tinggi;
            return Volume;
        }
            void settinggi (int parseint) {
                throw new UnsupportedOperationException("not support yet."); 
            }
   
    }
    
