
package Tabung;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CodingTabung {
    public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        Tabung.ProsesTabung Tabung = new Tabung.ProsesTabung ();
        try       
    {
        System.out.println("inputkan Jarijari");
        String r = dataIn.readLine();
        Tabung.setJarijari(Integer.parseInt (r));
        
        System.out.println("inputkan tinggi");
        String t = dataIn.readLine ();
        Tabung.setTinggi(Integer.parseInt (t));
        
        System.out.println("Jari jari tabung="+Tabung.getJarijari());
        System.out.println("Tinggi tabung="+Tabung.getTinggi ());
        System.out.println("Volume tabung="+Tabung.hitungVolume ());
    }
        catch (IOException e)
    {
        System.out.println("Data yang di input salah");
        
    }
   }
}
   
